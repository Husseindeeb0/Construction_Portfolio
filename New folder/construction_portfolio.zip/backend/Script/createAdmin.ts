import readline from 'readline'
import prisma from '../src/configs/prisma.js'
import { hashPassword } from '../src/utils/password.utils.js'
import { UserRole } from '@prisma/client'

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
})

const question = (query: string): Promise<string> => {
  return new Promise((resolve) => rl.question(query, resolve))
}

const run = async () => {
  try {
    console.log('=== Create Admin User Script ===\n')

    // Support command line arguments:
    // e.g. npm run create-admin -- admin@example.com "MyPassword123!"
    const args = process.argv.slice(2).filter((arg) => arg !== '--')
    let emailArg = args[0]
    let passwordArg = args[1]

    // If passed with a leading flag like --admin@example.com, strip the --
    if (emailArg && emailArg.startsWith('--')) {
      emailArg = emailArg.replace(/^--/, '')
    }

    let email = emailArg
    let password = passwordArg

    if (!email) {
      email = await question('Enter Admin Email: ')
    }

    if (!password) {
      password = await question('Enter Admin Password: ')
    }

    email = email.trim().toLowerCase()
    password = password.trim()

    if (!email || !password) {
      console.error('Error: Email and password are required.')
      process.exit(1)
    }

    const existingUser = await prisma.user.findUnique({
      where: { email },
    })

    if (existingUser) {
      console.log(`User with email "${email}" already exists with role: ${existingUser.role}.`)
      const upgrade = await question('Would you like to promote this existing user to ADMIN? (y/n): ')
      if (upgrade.trim().toLowerCase() === 'y') {
        const updated = await prisma.user.update({
          where: { email },
          data: { role: UserRole.ADMIN },
        })
        console.log(`Success: User "${updated.email}" promoted to ADMIN (ID: ${updated.id}).`)
      } else {
        console.log('Aborted.')
      }
      return
    }

    const passwordHash = await hashPassword(password)
    const newAdmin = await prisma.user.create({
      data: {
        email,
        passwordHash,
        role: UserRole.ADMIN,
      },
    })

    console.log(`\nSuccess! Admin account created successfully.`)
    console.log(`ID:    ${newAdmin.id}`)
    console.log(`Email: ${newAdmin.email}`)
    console.log(`Role:  ${newAdmin.role}`)
  } catch (error) {
    console.error('Failed to create admin user:', error)
  } finally {
    rl.close()
    await prisma.$disconnect()
    process.exit(0)
  }
}

run()
