import prisma from '../src/configs/prisma.js'
import { hashPassword } from '../src/utils/password.utils.js'
import { UserRole } from '@prisma/client'

async function main() {
  console.log('🌱 Starting database seed...\n')

  // 1. Seed Admin User
  const adminEmail = 'admin@example.com'
  const adminPassword = 'AdminPassword123!'
  const passwordHash = await hashPassword(adminPassword)

  const admin = await prisma.user.upsert({
    where: { email: adminEmail },
    update: {
      passwordHash,
      role: UserRole.ADMIN,
    },
    create: {
      email: adminEmail,
      passwordHash,
      role: UserRole.ADMIN,
    },
  })
  console.log(`✅ Admin user seeded: ${admin.email} (Password: ${adminPassword})`)

  // 2. Seed Company Profile
  await prisma.companyProfile.upsert({
    where: { id: 1 },
    update: {
      companyName: 'Constructify',
      logoUrl: '/images/hero.png',
      logoFileId: 'local-seed-logo-01',
      phoneNumber: '+1 (555) 234-6789',
      email: 'contact@constructify.com',
    },
    create: {
      id: 1,
      companyName: 'Constructify',
      logoUrl: '/images/hero.png',
      logoFileId: 'local-seed-logo-01',
      phoneNumber: '+1 (555) 234-6789',
      email: 'contact@constructify.com',
    },
  })
  console.log('✅ Company profile seeded')

  // 3. Seed Hero Section & Stats
  await prisma.heroStat.deleteMany({ where: { heroId: 1 } })
  await prisma.hero.upsert({
    where: { id: 1 },
    update: {
      badge: 'Trusted Construction Partner Since 1998',
      title: "Building Tomorrow's Infrastructure Today",
      description:
        'Voluptatem accusantium doloremque laudantium totam rem aperiam eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae.',
      backgroundImageUrl: '/images/construction_08.jpg',
      backgroundFileId: 'local-seed-hero-bg-01',
      stats: {
        create: [
          { label: 'Years Experience', value: '25+', displayOrder: 1 },
          { label: 'Projects Completed', value: '850+', displayOrder: 2 },
          { label: 'Team Experts', value: '120+', displayOrder: 3 },
          { label: 'Industry Awards', value: '35+', displayOrder: 4 },
        ],
      },
    },
    create: {
      id: 1,
      badge: 'Trusted Construction Partner Since 1998',
      title: "Building Tomorrow's Infrastructure Today",
      description:
        'Voluptatem accusantium doloremque laudantium totam rem aperiam eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae.',
      backgroundImageUrl: '/images/construction_08.jpg',
      backgroundFileId: 'local-seed-hero-bg-01',
      stats: {
        create: [
          { label: 'Years Experience', value: '25+', displayOrder: 1 },
          { label: 'Projects Completed', value: '850+', displayOrder: 2 },
          { label: 'Team Experts', value: '120+', displayOrder: 3 },
          { label: 'Industry Awards', value: '35+', displayOrder: 4 },
        ],
      },
    },
  })
  console.log('✅ Hero section & stats seeded')

  // 4. Seed About Section & Features
  await prisma.aboutFeature.deleteMany({ where: { aboutId: 1 } })
  await prisma.about.upsert({
    where: { id: 1 },
    update: {
      badge: 'About Our Company',
      title: 'We Build With Precision, Passion & Purpose',
      description:
        'Since 1998, we have been delivering world-class construction services across residential, commercial, and infrastructure sectors. Our commitment to quality craftsmanship and client satisfaction drives everything we do.',
      primaryImageUrl: '/images/construction_02.jpg',
      primaryImageId: 'local-seed-about-primary-01',
      secondaryImageUrl: '/images/construction_04.jpg',
      secondaryImageId: 'local-seed-about-secondary-01',
      features: {
        create: [
          {
            title: 'Licensed & Insured',
            description:
              'Fully certified with comprehensive coverage for every project we undertake.',
            icon: 'shield',
            displayOrder: 1,
            isActive: true,
          },
          {
            title: 'On-Time Delivery',
            description:
              'Proven track record of completing projects within schedule and budget.',
            icon: 'clock',
            displayOrder: 2,
            isActive: true,
          },
          {
            title: 'Expert Workforce',
            description:
              'Over 120 skilled professionals across all construction disciplines.',
            icon: 'users',
            displayOrder: 3,
            isActive: true,
          },
          {
            title: 'Award Winning',
            description:
              'Recognized with 35+ industry awards for quality and innovation.',
            icon: 'award',
            displayOrder: 4,
            isActive: true,
          },
        ],
      },
    },
    create: {
      id: 1,
      badge: 'About Our Company',
      title: 'We Build With Precision, Passion & Purpose',
      description:
        'Since 1998, we have been delivering world-class construction services across residential, commercial, and infrastructure sectors. Our commitment to quality craftsmanship and client satisfaction drives everything we do.',
      primaryImageUrl: '/images/construction_02.jpg',
      primaryImageId: 'local-seed-about-primary-01',
      secondaryImageUrl: '/images/construction_04.jpg',
      secondaryImageId: 'local-seed-about-secondary-01',
      features: {
        create: [
          {
            title: 'Licensed & Insured',
            description:
              'Fully certified with comprehensive coverage for every project we undertake.',
            icon: 'shield',
            displayOrder: 1,
            isActive: true,
          },
          {
            title: 'On-Time Delivery',
            description:
              'Proven track record of completing projects within schedule and budget.',
            icon: 'clock',
            displayOrder: 2,
            isActive: true,
          },
          {
            title: 'Expert Workforce',
            description:
              'Over 120 skilled professionals across all construction disciplines.',
            icon: 'users',
            displayOrder: 3,
            isActive: true,
          },
          {
            title: 'Award Winning',
            description:
              'Recognized with 35+ industry awards for quality and innovation.',
            icon: 'award',
            displayOrder: 4,
            isActive: true,
          },
        ],
      },
    },
  })
  console.log('✅ About section & features seeded')

  // 5. Seed Services Section & Services
  await prisma.service.deleteMany({ where: { serviceSectionId: 1 } })
  await prisma.serviceSection.upsert({
    where: { id: 1 },
    update: {
      title: 'Our Services',
      description:
        'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur',
      imageUrl: '/images/construction_07.jpg',
      imageId: 'local-seed-service-bg-01',
      imageText: 'We Deliver Excellence in Every Project',
      services: {
        create: [
          {
            title: 'Residential Building',
            description:
              'Neque porro quisquam est qui dolorem ipsum quia dolor sit amet consectetur adipisci velit.',
            icon: 'building',
            displayOrder: 1,
            isActive: true,
          },
          {
            title: 'Commercial Projects',
            description:
              'Ut enim ad minima veniam quis nostrum exercitationem ullam corporis suscipit laboriosam.',
            icon: 'briefcase',
            displayOrder: 2,
            isActive: true,
          },
          {
            title: 'Renovation & Remodeling',
            description:
              'Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae.',
            icon: 'hammer',
            displayOrder: 3,
            isActive: true,
          },
          {
            title: 'Road & Infrastructure',
            description:
              'Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet.',
            icon: 'Layers',
            displayOrder: 4,
            isActive: true,
          },
        ],
      },
    },
    create: {
      id: 1,
      title: 'Our Services',
      description:
        'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur',
      imageUrl: '/images/construction_07.jpg',
      imageId: 'local-seed-service-bg-01',
      imageText: 'We Deliver Excellence in Every Project',
      services: {
        create: [
          {
            title: 'Residential Building',
            description:
              'Neque porro quisquam est qui dolorem ipsum quia dolor sit amet consectetur adipisci velit.',
            icon: 'building',
            displayOrder: 1,
            isActive: true,
          },
          {
            title: 'Commercial Projects',
            description:
              'Ut enim ad minima veniam quis nostrum exercitationem ullam corporis suscipit laboriosam.',
            icon: 'briefcase',
            displayOrder: 2,
            isActive: true,
          },
          {
            title: 'Renovation & Remodeling',
            description:
              'Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae.',
            icon: 'hammer',
            displayOrder: 3,
            isActive: true,
          },
          {
            title: 'Road & Infrastructure',
            description:
              'Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet.',
            icon: 'Layers',
            displayOrder: 4,
            isActive: true,
          },
        ],
      },
    },
  })
  console.log('✅ Services section & services seeded')

  // 6. Seed Track Record Section & Stats
  await prisma.trackRecordStat.deleteMany({ where: { trackRecordSectionId: 1 } })
  await prisma.trackRecordSection.upsert({
    where: { id: 1 },
    update: {
      badge: 'OUR TRACK RECORD',
      title: 'Numbers That Speak for Our Commitment',
      description:
        'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium totam rem aperiam eaque ipsa quae ab illo inventore.',
      stats: {
        create: [
          {
            title: 'Projects Delivered',
            value: '850+',
            icon: 'chart',
            displayOrder: 1,
            isActive: true,
          },
          {
            title: 'Satisfied Clients',
            value: '620+',
            icon: 'smile',
            displayOrder: 2,
            isActive: true,
          },
          {
            title: 'Skilled Workers',
            value: '120+',
            icon: 'users',
            displayOrder: 3,
            isActive: true,
          },
          {
            title: 'Industry Awards',
            value: '35+',
            icon: 'award',
            displayOrder: 4,
            isActive: true,
          },
        ],
      },
    },
    create: {
      id: 1,
      badge: 'OUR TRACK RECORD',
      title: 'Numbers That Speak for Our Commitment',
      description:
        'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium totam rem aperiam eaque ipsa quae ab illo inventore.',
      stats: {
        create: [
          {
            title: 'Projects Delivered',
            value: '850+',
            icon: 'chart',
            displayOrder: 1,
            isActive: true,
          },
          {
            title: 'Satisfied Clients',
            value: '620+',
            icon: 'smile',
            displayOrder: 2,
            isActive: true,
          },
          {
            title: 'Skilled Workers',
            value: '120+',
            icon: 'users',
            displayOrder: 3,
            isActive: true,
          },
          {
            title: 'Industry Awards',
            value: '35+',
            icon: 'award',
            displayOrder: 4,
            isActive: true,
          },
        ],
      },
    },
  })
  console.log('✅ Track record section & stats seeded')

  // 7. Seed Project Categories
  const residentialCat = await prisma.projectCategory.upsert({
    where: { name: 'Residential' },
    update: { displayOrder: 1 },
    create: { name: 'Residential', displayOrder: 1 },
  })

  const commercialCat = await prisma.projectCategory.upsert({
    where: { name: 'Commercial' },
    update: { displayOrder: 2 },
    create: { name: 'Commercial', displayOrder: 2 },
  })

  const infrastructureCat = await prisma.projectCategory.upsert({
    where: { name: 'Infrastructure' },
    update: { displayOrder: 3 },
    create: { name: 'Infrastructure', displayOrder: 3 },
  })
  console.log('✅ Project categories seeded')

  // 8. Seed Projects
  await prisma.project.deleteMany({})
  await prisma.project.createMany({
    data: [
      {
        title: 'Sunset Ridge Villa',
        description: 'Premium residential complex with contemporary architecture and sustainable design.',
        imageUrl: '/images/construction_01.jpg',
        imageId: 'local-seed-project-01',
        displayOrder: 1,
        isActive: true,
        projectCategoryId: residentialCat.id,
      },
      {
        title: 'Central Shopping Plaza',
        description: 'Multi-level commercial retail destination with modern energy-efficient amenities.',
        imageUrl: '/images/construction_03.jpg',
        imageId: 'local-seed-project-02',
        displayOrder: 2,
        isActive: true,
        projectCategoryId: commercialCat.id,
      },
      {
        title: 'Northern Rail Terminal',
        description: 'Multi-modal transit and infrastructure hub connecting urban transportation lines.',
        imageUrl: '/images/construction_05.jpg',
        imageId: 'local-seed-project-03',
        displayOrder: 3,
        isActive: true,
        projectCategoryId: infrastructureCat.id,
      },
      {
        title: 'Grand Horizon Heights',
        description: 'High-rise residential tower with luxury penthouses and seismic-resistant engineering.',
        imageUrl: '/images/construction_06.jpg',
        imageId: 'local-seed-project-04',
        displayOrder: 4,
        isActive: true,
        projectCategoryId: residentialCat.id,
      },
      {
        title: 'Metropolitan Logistics Park',
        description: 'Modern warehousing and distribution facility built for high-throughput supply chains.',
        imageUrl: '/images/construction_09.jpg',
        imageId: 'local-seed-project-05',
        displayOrder: 5,
        isActive: true,
        projectCategoryId: commercialCat.id,
      },
      {
        title: 'Coastal Highway Viaduct',
        description: 'Elevated highway corridor engineered for heavy traffic and marine durability.',
        imageUrl: '/images/construction_10.jpg',
        imageId: 'local-seed-project-06',
        displayOrder: 6,
        isActive: true,
        projectCategoryId: infrastructureCat.id,
      },
    ],
  })
  console.log('✅ Projects seeded')

  console.log('\n🎉 Seed finished successfully!')
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
